#Write a Python program to write a Python dictionary to a csv file. After writing the CSV file
#read the CSV file and display the content.

f = open("C:/Users/student.MCALAB/Desktop/details.csv", 'a')
import json
thisdict = {
        "brand":"ford",
        "model":"mustang",
        "year":"1964"
                }
result =json.dumps(thisdict)
f.write(result)
f.close()
f = open("C:/Users/student.MCALAB/Desktop/details.csv", 'r')
print(f.read())
