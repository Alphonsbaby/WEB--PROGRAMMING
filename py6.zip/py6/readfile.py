#Write a Python program to read a file line by line and store it into a list.
f=open("guru99.txt","r")
content=f.readlines()
print("file content is",content)
x=['anu baby']
x.append(content)
print("after appand line is",x)

