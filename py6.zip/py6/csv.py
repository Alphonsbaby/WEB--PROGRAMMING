#Write a Python program to read each row from a given csv file and print a list of strings.
#import csv
f=open("D:/alphons/proex.csv",'r')
content=f.readlines()
print("file content is",content)
