#Python program to copy odd lines of one file to other
f=open("demo1.txt","r")
f1=open("write.txt","w")
content=f.readlines()
type(content)
for i in range(0,len(content)):
    if(i%2!=0):
        f1.write(content[i])
f1.close()
f1 = open("write.txt", "r")
cont1 = f1.read()
print(cont1)
f.close()
f1.close()