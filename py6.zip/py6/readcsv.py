#Write a Python program to read specific columns of a given CSV file and print the content of the columns
import csv

import csv
csvfile=open("D:/alphons/proex.csv",'r')
data = csv.reader(csvfile)
print("Name")
print("---------------------------------")
for row in data:
  print(row)
