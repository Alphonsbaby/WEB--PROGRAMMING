<!DOCTYPE html>
<html>
<body>

<?php
$a = array("anu", "alphonsa", "aneesha");
sort($a);
print_r($a);

echo "<br>";
?>

</body>
</html>