<html>
<head>
<title>
Variable Function:print_r()
</title>
</head>
<body>
 <pre>
 <?php
$data = array('e_no'=>106680307009,'e_name'=>'Bipin R.
Prajapati','S.P.I'=>array('1st'=>7.75,'2nd'=>8.27,'3rd'=>8.20,'4th'=>7.57));
print_r ($data);
 ?>
 </pre>
</body>
</html>