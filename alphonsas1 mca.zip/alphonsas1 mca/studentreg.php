<html>
<head>
<title>Outline a registration form using PHP and do necessary validations.</title>
</head>
<body>
<form action = "regform.php" method = "POST">
Name:
<input type = "text" name = "txtname">
<br><br>
hall ticket  no.:
<input type = "text" name = "txtr_no">
<br><br>
Address:
<textarea name = "add" type = "textarea"></textarea>
<br><br>
<input type = "Submit" name = "insert" value = "Save">
<input type = "Reset" value = "Cancle">
</form>
</body>