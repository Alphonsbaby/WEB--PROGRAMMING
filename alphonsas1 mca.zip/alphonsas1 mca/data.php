<html>
<head>
<title>get data from another page</title>
</head>
<body>
 <?php

echo "Name:" .$_POST["txtname"]."</br>";
echo "Roll no.:".$_POST["txtr_no"]."</br>";
echo "Address:".$_POST["add"]."</br>";
echo "Contact No.:".$_POST["txtc_no"]."</br>";
echo "Email ID:".$_POST["txteid"]."</br>";

 ?>
</body>