
 <?php

$servername = "localhost";
$username = "20mca010";
$password = "2348";
$dbname = "20mca010";

// Create connection
$con = new mysqli($servername, $username, $password, $dbname);

//if($con)
//{
//echo "Mysql connection ok<br>";
//mysql_select_db("getdata",$con);
$name =$_POST['txtname'];
$rollno = $_POST['txtr_no'];
$address = $_POST['add'];
$sql = "INSERT INTO getdata (name,rollno,address)
values('$name','$rollno','$address')";

if (mysqli_query($con, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($con);
}

mysqli_close($conn);
?>
//if(mysql_query($insert,$con))
//{
//echo "Data inserted successfully<br>";
//}
// ?>
</body>