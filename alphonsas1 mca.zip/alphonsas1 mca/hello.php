<Html>
<Head>
<Title> My Simple Program </Title>
</head>
<Body>
 <?php
 echo "Hello World"
 ?>
</Body>
</Html>