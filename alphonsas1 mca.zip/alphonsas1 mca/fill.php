<html>
<head>
<title>insert data in form</title>
</head>
<body>
<form action = "data.php" method = "POST">
Name:
<input type = "text" name = "txtname">
<br><br>
Roll no.:
<input type = "text" name = "txtr_no">
<br><br>
Address:
<textarea name = "add" type = "textarea"></textarea>
<br><br>
Contyact No:
<input type = "text" name = "txtc_no">
<br><br>
Email ID:
<input type = "text" name = "txteid">
<br><br>
<input type = "Submit" name = "insert" value = "Save">
<input type = "Reset" value = "Cancle">
</form>
</body>
</html>